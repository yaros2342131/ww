Пропсы Брейнрот Лаборатории для UEFN — 33 шт.

Импорт: Content Browser → папка LabProps → Import → Meshes/SM_*.fbx (текстуры встроены).
В окне FBX: Static Mesh, Combine Meshes — ВЫКЛ, Auto Generate Collision — ВЫКЛ (UCX внутри).
Сантиметры, пивот — центр основания, лицом по +X.

Для Verse (SpawnProp) каждому мешу нужен Creative Prop: ПКМ по мешу → создать Blueprint-класс
на базе Creative Prop (BuildingProp) — такой ассет попадает в @editable-массивы lab_manager_device.
Кучи мем-мусора (JunkPile_Gold/Rainbow/Lava) ставятся руками в одну точку для каждой кучи
и указываются в lab_junk_device → Piles → Props (Золотой, Радужный, Лавовый).
Порядок массивов: CapsuleProps = Common, Rare, Epic, Legendary, Mythic, Iconic;
PedestalProps = Base, Gold, Diamond, Rainbow, Lava, Viral, Cosmic; AuraProps = IdealAura.

Подробно: docs/brainrot-lab/03-assets.md
